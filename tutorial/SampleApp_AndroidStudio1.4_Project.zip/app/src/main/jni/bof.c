#include <stdio.h>
#include <stdlib.h>
#include "xyz_whoya_fileio_MainActivity.h"

#ifdef __cplusplus
extern "C" {
#endif

void bof(char * big, int num) {
    char buff[4] = {0, };
    memcpy(buff, big, num);
    return;
}

JNIEXPORT void JNICALL Java_xyz_whoya_fileio_MainActivity_BoF
(JNIEnv * env, jobject thisObj, jstring inJNIStr)
{
    const char *inCStr = (*env)->GetStringUTFChars(env, inJNIStr, NULL);

    FILE *fd = fopen( inCStr, "r" );

    char a[100] = {0,};
    char b[100] = {0,};
    char c[100] = {0,};

    int i, size = 0;
    size = fread( a, 1, 100, fd );
    fclose( fd );


    for ( i = 0 ; i < size ; i++ ) {
        b[i] = a[i] + 5;
    }
    strcpy(c, b);

    for ( i = 0 ; i < size ; i++ ) {
        b[i] = c[i] - 2;
    }
    strcpy(c, b);

    //b[8] = a[6];
    //b[9] = a[7];
    //b[10] = a[0];
    //b[11] = a[1];
    bof(c, size);
}

#ifdef __cplusplus
}
#endif